package com.example.latquiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
