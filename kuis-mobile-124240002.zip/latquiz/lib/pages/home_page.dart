import 'package:flutter/material.dart';
import '../data/menu_data.dart';
import 'detail_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _query = '';
  String _category = 'Semua';
  final _categories = ['Semua', 'T-Shirt', 'Jacket', 'Pants'];

  @override
  Widget build(BuildContext context) {
    // Bonus: search + filter kategori
    final items = catalog.where((m) {
      final okCat = _category == 'Semua' || m.type == _category;
      final okQ = m.productName.toLowerCase().contains(_query.toLowerCase());
      return okCat && okQ;
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 0),
          child: TextField(
            onChanged: (v) => setState(() => _query = v),
            decoration: InputDecoration(
              hintText: 'Cari Product...',
              prefixIcon: const Icon(Icons.search),
              isDense: true,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20)),
            ),
          ),
        ),
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: _categories
                .map((c) => Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(c),
                        selected: _category == c,
                        onSelected: (_) => setState(() => _category = c),
                      ),
                    ))
                .toList(),
          ),
        ),
        Expanded(
          child: items.isEmpty
              ? const Center(child: Text('Product tidak ditemukan'))
              : ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (context, i) {
                    final m = items[i];
                    return ListTile(
                      leading: Hero(
                        tag: 'menu-${m.id}',
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: Image.network(
                            m.imageUrl,
                            width: 48,
                            height: 48,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => const SizedBox(
                              width: 48,
                              height: 48,
                              child: Icon(Icons.fastfood),
                            ),
                          ),
                        ),
                      ),
                      title: Text(m.productName, style: const TextStyle(fontSize: 14)),
                      subtitle: Text(
                        '${m.type}\n${m.price}',
                        style: const TextStyle(fontSize: 11),
                      ),
                      isThreeLine: true,
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => DetailPage(menu: m)),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
