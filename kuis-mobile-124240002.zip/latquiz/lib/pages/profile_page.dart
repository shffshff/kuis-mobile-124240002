import 'package:flutter/material.dart';
import 'login_page.dart';

class ProfilePage extends StatelessWidget {
  final String username;
  const ProfilePage({super.key, required this.username});

  void _logout(BuildContext context) {
    // Hapus semua route agar tombol Back tidak bisa kembali ke Home
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: Colors.deepPurple.shade50,
            child: Icon(Icons.person, size: 30, color: Colors.deepPurple.shade700),
          ),
          const SizedBox(height: 16),
          const Text('Username',
              style: TextStyle(fontSize: 12, color: Colors.black45)),
          const SizedBox(height: 4),
          Text(username,
              style:
                  const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          FilledButton.tonalIcon(
            onPressed: () => _logout(context),
            icon: const Icon(Icons.logout, size: 16),
            label: const Text('Logout'),
          ),
        ],
      ),
    );
  }
}
